import React from 'react';
import {Composition} from 'remotion';
import {AnansePromo} from './Promo';

export const RemotionRoot: React.FC = () => (
  <Composition
    id="AnanseSaaSPromo"
    component={AnansePromo}
    durationInFrames={1920}
    fps={60}
    width={1920}
    height={1080}
    defaultProps={{}}
  />
);
