import React from 'react';
import {
  AbsoluteFill, Audio, Img, Sequence, interpolate, spring,
  staticFile, useCurrentFrame, useVideoConfig,
} from 'remotion';

const C = {
  ink: '#08090D', paper: '#F7F7F5', muted: '#A6A6AD',
  gold: '#F4C344', orange: '#F06A2B', blue: '#4D9CF4',
  panel: '#171923', line: 'rgba(255,255,255,.15)',
};
const clamp = {extrapolateLeft: 'clamp' as const, extrapolateRight: 'clamp' as const};

const Fade: React.FC<{children: React.ReactNode; start?: number}> = ({children, start=0}) => {
  const f = useCurrentFrame();
  const {fps} = useVideoConfig();
  const v = spring({frame: Math.max(0, f-start), fps, config: {damping: 18, stiffness: 100}});
  return <div style={{opacity: v, transform: `translateY(${(1-v)*42}px)`}}>{children}</div>;
};

const Eyebrow: React.FC<{children: React.ReactNode; dark?: boolean}> = ({children, dark=true}) =>
  <div style={{fontSize: 22, letterSpacing: '0.24em', fontWeight: 700, color: dark ? C.gold : '#8A6718', textTransform:'uppercase'}}>{children}</div>;

const Big: React.FC<{children: React.ReactNode; size?: number; dark?: boolean; align?: 'left'|'center'}> =
  ({children, size=100, dark=true, align='left'}) =>
  <div style={{fontSize:size, lineHeight:.98, letterSpacing:'-.055em', fontWeight:800, color: dark ? '#FFFFFF' : C.ink, textAlign:align}}>{children}</div>;

const Brand: React.FC<{dark?: boolean}> = ({dark=true}) =>
  <div style={{fontWeight:900, letterSpacing:'-.075em', fontSize:72, lineHeight:.8, color: dark?'#fff':C.ink}}>
    ananse<span style={{display:'block', fontSize:24, fontWeight:400, letterSpacing:'.36em', textAlign:'center', marginTop:15}}>AFRICA</span>
  </div>;

const Glow: React.FC<{color?: string; x?: string; y?: string; size?: number}> =
  ({color=C.blue,x='50%',y='50%',size=700}) =>
  <div style={{position:'absolute', left:x, top:y, width:size, height:size, transform:'translate(-50%,-50%)',
    borderRadius:'50%', background:`radial-gradient(circle, ${color}35 0%, ${color}13 38%, transparent 70%)`, filter:'blur(18px)'}}/>;

const Glass: React.FC<{children: React.ReactNode; style?: React.CSSProperties}> = ({children,style={}}) =>
  <div style={{background:'linear-gradient(135deg,rgba(255,255,255,.13),rgba(255,255,255,.035))',
    border:'1px solid rgba(255,255,255,.2)', borderRadius:28, boxShadow:'0 24px 70px rgba(0,0,0,.35)',
    backdropFilter:'blur(18px)', ...style}}>{children}</div>;

const Pill: React.FC<{children: React.ReactNode; color?: string}> = ({children,color=C.gold}) =>
  <div style={{padding:'16px 24px', borderRadius:999, border:`1px solid ${color}77`, background:`${color}18`,
    color:'#fff', fontSize:22, fontWeight:600, whiteSpace:'nowrap'}}>{children}</div>;

const Scene1Hook: React.FC = () => {
  const f=useCurrentFrame();
  const x=interpolate(f,[0,30,210,240],[-80,0,0,60],clamp);
  const star=interpolate(f,[175,239],[0,26],clamp);
  return <AbsoluteFill style={{background:C.ink, color:'#fff', justifyContent:'center', padding:110, overflow:'hidden',transform:`scale(1.045) translate(${Math.sin(f/47)*10}px, ${Math.cos(f/61)*8}px)`, transformOrigin:'center center',}}>
    <Glow color={C.orange} x="82%" y="22%" size={850}/>
    <Glow color={C.blue} x="10%" y="90%" size={700}/>
    <div style={{position:'absolute',right:110,top:90}}><Eyebrow>ANANSE • AFRICA'S CREATIVE ECONOMY</Eyebrow></div>
    <div style={{transform:`translateX(${x}px)`}}>
      <Fade><Big size={150}>MADE IN</Big></Fade>
      <Fade start={12}><Big size={190}><span style={{color:C.gold}}>AFRICA.</span> READY</Big></Fade>
      <Fade start={26}><Big size={190}>FOR THE WORLD.</Big></Fade>
    </div>
    <div style={{position:'absolute',bottom:105,left:115,fontSize:26,color:'#C9C9D0',letterSpacing:'.08em'}}>DESIGN  /  MAKE  /  SELL</div>
    <div style={{position:'absolute',right:145,bottom:100,fontSize:100,color:C.gold,transform:`rotate(${f*2}deg) scale(${1+star*.025})`}}>✦</div>
  </AbsoluteFill>;
};

const Scene2Brand: React.FC = () => {
  const f=useCurrentFrame();
  const s=spring({frame:f,fps:60,config:{damping:16,stiffness:120,mass:.8}});
  return <AbsoluteFill style={{background:C.paper,justifyContent:'center',padding:100,overflow:'hidden',transform:`scale(1.045) translate(${Math.sin(f/47)*10}px, ${Math.cos(f/61)*8}px)`, transformOrigin:'center center',}}>
    <Glow color={C.gold} x="85%" y="18%" size={650}/>
    <div style={{display:'flex',justifyContent:'space-between',alignItems:'center'}}>
      <div style={{maxWidth:900}}>
        <Eyebrow dark>THE CREATIVE COMMERCE PLATFORM</Eyebrow>
        <div style={{height:34}}/>
        <div style={{fontSize:116,lineHeight:.98,letterSpacing:'-.06em',fontWeight:850,color:C.ink}}>African talent.<br/><span style={{color:C.orange}}>Global reach.</span></div>
        <div style={{fontSize:34,lineHeight:1.35,color:'#4C4C52',marginTop:42,maxWidth:790}}>A connected ecosystem helping African designers and artisans create, grow and sell to the world.</div>
      </div>
      <div style={{transform:`scale(${s}) rotate(-5deg)`, marginRight:20}}>
        <Glass style={{background:'#090A0F',padding:'65px 60px',borderRadius:36}}>
          <Brand/>
          <div style={{marginTop:45,display:'flex',gap:12}}><Pill>MARKETPLACE</Pill><Pill color={C.orange}>DESIGN</Pill></div>
        </Glass>
      </div>
    </div>
    <div style={{position:'absolute',bottom:68,left:105,color:'#777',fontSize:20,letterSpacing:'.2em'}}>ANANSE.COM</div>
  </AbsoluteFill>;
};

const Scene3Ecosystem: React.FC = () => {
  const f=useCurrentFrame();
  const items=[['DESIGNERS','Creative talent'],['ARTISANS','Skilled makers'],['CUSTOMERS','Global demand'],['PARTNERS','Growth network']];
  return <AbsoluteFill style={{background:'#0B0C14',justifyContent:'center',alignItems:'center',overflow:'hidden',transform:`scale(1.045) translate(${Math.sin(f/47)*10}px, ${Math.cos(f/61)*8}px)`, transformOrigin:'center center',}}>
    <Glow color={C.blue} x="50%" y="52%" size={900}/>
    <Eyebrow>ONE ECOSYSTEM. MORE POSSIBILITIES.</Eyebrow>
    <div style={{fontSize:104,fontWeight:850,letterSpacing:'-.06em',color:'#fff',marginTop:28}}>Connect the dots.</div>
    <svg width="1100" height="500" viewBox="0 0 1100 500" style={{position:'absolute',top:390}}>
      {[0,1,2].map(i=><circle key={i} cx="550" cy="245" r={120+i*95} fill="none" stroke={C.blue} strokeOpacity={.22-i*.04} strokeWidth="2"/>)}
      <path d="M550 245 L170 100 M550 245 L930 100 M550 245 L170 390 M550 245 L930 390" stroke="#F4C344" strokeOpacity=".55" strokeWidth="2" strokeDasharray="10 12"/>
    </svg>
    <Glass style={{position:'absolute',left:210,top:400,padding:28,width:310}}><Eyebrow>DESIGNERS</Eyebrow><div style={{fontSize:30,color:'#fff',marginTop:12}}>Ideas become products</div></Glass>
    <Glass style={{position:'absolute',right:210,top:400,padding:28,width:310}}><Eyebrow>ARTISANS</Eyebrow><div style={{fontSize:30,color:'#fff',marginTop:12}}>Skills become value</div></Glass>
    <Glass style={{position:'absolute',left:210,bottom:75,padding:28,width:310}}><Eyebrow>PARTNERS</Eyebrow><div style={{fontSize:30,color:'#fff',marginTop:12}}>Support that scales</div></Glass>
    <Glass style={{position:'absolute',right:210,bottom:75,padding:28,width:310}}><Eyebrow>CUSTOMERS</Eyebrow><div style={{fontSize:30,color:'#fff',marginTop:12}}>Discover Africa</div></Glass>
    <div style={{position:'absolute',top:590,left:'50%',transform:'translateX(-50%)',width:250,height:150,borderRadius:32,background:'linear-gradient(135deg,#F4C344,#F06A2B)',display:'flex',alignItems:'center',justifyContent:'center',boxShadow:'0 0 90px #F4C34466'}}>
      <div style={{fontSize:56,fontWeight:900,color:'#090A0F',letterSpacing:'-.08em'}}>ananse</div>
    </div>
  </AbsoluteFill>;
};

const ScreenshotCard: React.FC<{file:string; title:string; subtitle:string; left?:boolean}> = ({file,title,subtitle,left=false}) => {
  const f=useCurrentFrame();
  const {fps}=useVideoConfig();
  const p=spring({frame:f,fps,config:{damping:18,stiffness:100}});
  return <div style={{display:'flex',gap:44,alignItems:'center',flexDirection:left?'row-reverse':'row',transform:`translateY(${(1-p)*55}px)`,opacity:p}}>
    <div style={{width:520,height:650,borderRadius:28,overflow:'hidden',background:'#fff',border:'8px solid #fff',boxShadow:'0 30px 90px #0008',transform:'perspective(1200px) rotateY(-8deg) rotateX(3deg)'}}>
      <Img src={staticFile(`assets/${file}`)} style={{
        width:'100%',height:'100%',objectFit:'cover',objectPosition:'top',
        transform:`scale(${1.06+Math.sin(f/70)*0.025}) translate(${Math.sin(f/53)*9}px, ${Math.cos(f/67)*12}px)`,
      }}/>
    </div>
    <div style={{width:650}}>
      <Eyebrow>{subtitle}</Eyebrow>
      <div style={{fontSize:76,lineHeight:1.02,fontWeight:850,letterSpacing:'-.05em',color:'#fff',marginTop:26}}>{title}</div>
      <div style={{height:8,width:170,background:`linear-gradient(90deg,${C.gold},${C.orange})`,borderRadius:9,marginTop:34}}/>
    </div>
  </div>;
};

const Scene4Platform: React.FC = () => {
  const f=useCurrentFrame();
  return <AbsoluteFill style={{background:'#10111A',justifyContent:'center',padding:100,overflow:'hidden',transform:`scale(1.045) translate(${Math.sin(f/47)*10}px, ${Math.cos(f/61)*8}px)`, transformOrigin:'center center',}}>
    <Glow color={C.orange} x={`${50+Math.sin(f/75)*12}%`} y="50%" size={900}/>
    <div style={{position:'absolute',top:70,left:105}}><Eyebrow>THE PLATFORM IN ACTION</Eyebrow></div>
    <ScreenshotCard file="img1.jpg" subtitle="01 / MARKETPLACE" title="A global storefront for African creativity."/>
  </AbsoluteFill>;
};

const Scene5Build: React.FC = () => {
  const f=useCurrentFrame();
  return <AbsoluteFill style={{background:C.paper,justifyContent:'center',padding:100,overflow:'hidden',transform:`scale(1.045) translate(${Math.sin(f/47)*10}px, ${Math.cos(f/61)*8}px)`, transformOrigin:'center center',}}>
    <Glow color={C.gold} x={`${50+Math.sin(f/75)*12}%`} y="80%" size={800}/>
    <div style={{position:'absolute',top:75,left:105}}><Eyebrow dark>BUILT TO HELP CREATIVES GROW</Eyebrow></div>
    <ScreenshotCard file="img4.jpg" subtitle="02 / MASTERCLASSES" title="Learn. Make. Build a business."/>
  </AbsoluteFill>;
};

const Scene6Impact: React.FC = () => {
  const f=useCurrentFrame();
  const count=Math.round(interpolate(f,[0,100],[0,7500],clamp));
  return <AbsoluteFill style={{background:'#090A10',justifyContent:'center',padding:100,overflow:'hidden',transform:`scale(1.045) translate(${Math.sin(f/47)*10}px, ${Math.cos(f/61)*8}px)`, transformOrigin:'center center',}}>
    <Glow color={C.blue} x="80%" y="45%" size={850}/>
    <div style={{display:'flex',justifyContent:'space-between',alignItems:'center'}}>
      <div style={{maxWidth:900}}>
        <Eyebrow>THE ANANSE CENTER FOR DESIGN</Eyebrow>
        <div style={{fontSize:112,lineHeight:.98,fontWeight:850,letterSpacing:'-.06em',color:'#fff',marginTop:35}}>Space to<br/><span style={{color:C.gold}}>make impact.</span></div>
        <div style={{fontSize:31,color:'#C8C8D0',lineHeight:1.4,marginTop:36}}>Studios. Equipment. Training. Production support.</div>
        <div style={{display:'flex',gap:20,marginTop:44}}><Pill>1,200 SQM FACILITY</Pill><Pill color={C.orange}>75+ MACHINES</Pill></div>
      </div>
      <div style={{width:580}}>
        <div style={{fontSize:22,color:'#B8B8C0',letterSpacing:'.2em'}}>CREATIVES TRAINED ANNUALLY</div>
        <div style={{fontSize:142,fontWeight:900,color:'#fff',letterSpacing:'-.07em',marginTop:14}}>{count.toLocaleString('en-US')}<span style={{color:C.gold}}>+</span></div>
        <div style={{height:12,background:'#30313B',borderRadius:20,marginTop:18,overflow:'hidden'}}><div style={{height:'100%',width:`${Math.min(100,count/75)}%`,background:`linear-gradient(90deg,${C.blue},${C.gold})`,borderRadius:20}}/></div>
        <div style={{fontSize:25,color:'#B8B8C0',marginTop:18}}>20+ courses • 10+ specialised studios</div>
      </div>
    </div>
  </AbsoluteFill>;
};

const Scene7Outro: React.FC = () => {
  const f=useCurrentFrame();
  const spin=interpolate(f,[0,150],[0,180],clamp);
  const scale=spring({frame:f,fps:60,config:{damping:14,stiffness:100}});
  return <AbsoluteFill style={{background:C.paper,justifyContent:'center',alignItems:'center',overflow:'hidden',transform:`scale(1.045) translate(${Math.sin(f/47)*10}px, ${Math.cos(f/61)*8}px)`, transformOrigin:'center center',}}>
    <Glow color={C.gold} x="50%" y="45%" size={900}/>
    <div style={{fontSize:40,letterSpacing:'.3em',fontWeight:800,color:'#8A6718'}}>CREATE. CONNECT. THRIVE.</div>
    <div style={{marginTop:70,transform:`scale(${scale})`,textAlign:'center'}}><Brand dark/></div>
    <div style={{fontSize:34,marginTop:70,color:'#555',letterSpacing:'.18em'}}>ANANSE.COM</div>
    <div style={{position:'absolute',right:250,top:180,fontSize:120,color:C.orange,transform:`rotate(${spin}deg)`}}>✦</div>
    <div style={{position:'absolute',bottom:75,fontSize:22,letterSpacing:'.2em',color:'#888'}}>MADE BY AFRICA. DELIVERED TO THE WORLD.</div>
  </AbsoluteFill>;
};

export const AnansePromo: React.FC = () => (
  <AbsoluteFill style={{background:C.ink,fontFamily:'Inter, Plus Jakarta Sans, Arial, sans-serif'}}>
    <Audio src={staticFile('assets/music.mp3')} volume={1}/>
    <Sequence from={0} durationInFrames={240}><Scene1Hook/></Sequence>
    <Sequence from={240} durationInFrames={240}><Scene2Brand/></Sequence>
    <Sequence from={480} durationInFrames={360}><Scene3Ecosystem/></Sequence>
    <Sequence from={840} durationInFrames={360}><Scene4Platform/></Sequence>
    <Sequence from={1200} durationInFrames={360}><Scene5Build/></Sequence>
    <Sequence from={1560} durationInFrames={360}><Scene6Impact/></Sequence>
    <Sequence from={1800} durationInFrames={120}><Scene7Outro/></Sequence>
  </AbsoluteFill>
);
