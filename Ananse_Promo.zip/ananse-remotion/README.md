# Ananse Remotion Promo

A 32-second, 1920×1080, 60fps promotional video project.

## Run
```bash
npm install
npm run start
```
Open the Remotion Studio URL and choose `AnanseSaaSPromo`.

Render:
```bash
npm run render
```

## Short file guide
- `src/Promo.tsx` — all seven scenes and animation
- `src/Root.tsx` — composition setup
- `src/index.ts` — Remotion entry point
- `public/assets/music.mp3` — supplied soundtrack
- `public/assets/img1.jpg` … `img8.png` — supplied website screenshots

## Motion
Every scene now has continuous deterministic camera drift throughout its duration. Screenshot imagery also uses continuous pan/zoom motion; animated glows and scene-specific motion provide additional movement. There are no intentionally held, motionless full-frame shots. Animation is driven by Remotion frame state, not timers or randomness.

The original audio and screenshot assets are included unchanged, apart from shorter filenames.
